import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class TestFechaDePagoQuincena {
    private static final String DIAS_FESTIVOS = "/home/edier_sanchez/Documents/pruebaKonecta/src/dias_festivos.txt";
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Ingrese la fecha (yyyy-mm-dd): ");
        String fechaIngresada = input.nextLine();
        LocalDate fecha = LocalDate.parse(fechaIngresada);

        DiasFestivos cargarDiasFestivos = new DiasFestivos();
        List<LocalDate> diasFestivos = cargarDiasFestivos.cargarDiasFestivos(DIAS_FESTIVOS);
        LocalDate fechaDePago = FechaDePagoQuincena.obtenerFechaPagoQuincena(fecha, diasFestivos);
        System.out.println("La fecha de pago de la quincena es: " + fechaDePago);
    }
}
